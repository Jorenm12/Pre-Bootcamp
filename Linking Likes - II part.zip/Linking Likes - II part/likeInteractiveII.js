// Button #1 //
var button= 1;
var countElement = document.querySelector("#FBlike");

console.log(countElement);


function add1() {
    button++;
    countElement.innerText = button + " like(s)";
    console.log(button);
}

// Button #2 //
var button2= 1;
var countElement2 = document.querySelector("#FBlike_second");

console.log(countElement2);


function add2() {
    button2++;
    countElement2.innerText = button2 + " like(s)";
    console.log(button2);
}

// Button #3 //

var button3= 1;
var countElement3 = document.querySelector("#FBlike_third");

console.log(countElement3);


function add3() {
    button3++;
    countElement3.innerText = button3 + " like(s)";
    console.log(button3);
}
