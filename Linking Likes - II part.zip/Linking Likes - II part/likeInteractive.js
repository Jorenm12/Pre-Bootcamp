var button= 1;
var countElement = document.querySelector("#FBlike");

console.log(countElement);


function add1() {
    button++;
    countElement.innerText = button + " like(s)";
    console.log(button);
}
